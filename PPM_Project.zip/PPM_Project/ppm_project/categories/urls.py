from django.urls import path

from .views import (
    CategorieListView,
    CategorieDetailView,
    CategorieEditView,
    CategorieDeleteView,
    CategorieCreateView,

)

urlpatterns = [
    path('', CategorieListView.as_view(), name="list-categories"),
    path('<int:pk>', CategorieDetailView.as_view(), name="category-detail"),
    path("<int:pk>/edit/", CategorieEditView.as_view(), name="category_edit"),
    path("<int:pk>/delete/", CategorieDeleteView.as_view(), name="category_delete"),
    path("new/", CategorieCreateView.as_view(), name="category_create"),

]
