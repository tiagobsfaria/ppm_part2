from django.contrib import admin
from .models import Categorie

# Register your models here.

admin.site.register(Categorie)
