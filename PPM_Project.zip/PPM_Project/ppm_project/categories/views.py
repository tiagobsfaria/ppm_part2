from django.shortcuts import render
from django.views.generic import ListView, DetailView
from django.views.generic.edit import UpdateView, DeleteView, CreateView
from django.urls import reverse_lazy
from django.shortcuts import get_object_or_404
from .models import Categorie
from posts.models import Post

# Create your views here.
class CategorieListView(ListView):
    model = Categorie
    template_name = "categories_list.html"


def CategorieView(request, cats):

    return render(request, 'posts.html', {"cats":cats})

class CategorieCreateView(CreateView):
    model = Categorie
    template_name ="categorie_create.html"
    fields = (
        "title",
        "description",
        "category_image",
    )
    success_url = reverse_lazy("list-categories")

    def form_valid(self, form):
        form.instance.author = self.request.user  # Set the author to the logged-in user
        return super().form_valid(form)

class CategorieDeleteView(DeleteView):
    model = Categorie
    template_name = "categorie_delete.html"

    success_url = reverse_lazy("list-categories")

class CategorieEditView(UpdateView):
    model = Categorie
    template_name = "categorie_edit.html"
    fields = (
        "title",
        "description",
    )
    success_url = reverse_lazy("list-categories")

class CategorieDetailView(DetailView):
    model = Categorie
    template_name = "categorie_detail.html"