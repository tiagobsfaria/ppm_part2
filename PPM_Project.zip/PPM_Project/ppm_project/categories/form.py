from django import forms
from .models import Categorie


class CategorieForm(forms.ModelForm):
    title = forms.CharFiel(widgey=forms.TextInput(attrs={'class':'form-control'}))
    description = forms.CharFiel(widgey=forms.TextInput(attrs={'class': 'form-control'}))

    class Meta:
        model = Categorie
        fields = ('title', 'description', 'category_image', 'author')